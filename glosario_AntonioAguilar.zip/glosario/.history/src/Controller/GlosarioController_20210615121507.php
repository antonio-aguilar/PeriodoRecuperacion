<?php
// src/Controller/GlosarioController.php
namespace App\Controller;
use App\Entity\Glosario;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController {
    public function portada() {
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        /* Obtenenemos el repositorio de Glosario y buscamos en el usando la id de la palabra */
        $palabras = $entityManager->getRepository(Glosario::class)->findAll();

        /* Pasamos la palabra a una plantilla que se encargue de mostrar sus datos. */
        return $this->render('portada.html.twig', array(
            'palabras' => $palabras,
        ));
    }

    public function definicion($id) {
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        /* Obtenenemos el repositorio de Glosario y buscamos en el usando la id de la palabra */
        $datos = $entityManager->getRepository(Glosario::class)->find($id);

        /* Pasamos la palabra a una plantilla que se encargue de mostrar sus datos. */
        return $this->render('definicion.html.twig', array(
            'datos' => $datos,
        ));
    }

    public function anadir(Request $request)
    {
        $anadir = new Anadir();
        
        $form = $this->createFormBuilder($apuesta)
            ->add('palabra', TextType::class)
            ->add('definicion', TextType::class)
            ->add('save', SubmitType::class,
                array('label' => 'Añadir Palabra'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // De esta manera podemos rellenar la variable $apuesta
            // con los datos del formulario.
            $anadir = $form->getData();
            // Ahora podríamos guardarla en la base de datos, redirigir
            // a una página de confirmación, crear un mensaje...
        }

        return $this->render('anadir.html.twig', array(
            'form' => $form->createView(),
        ));
    }
}