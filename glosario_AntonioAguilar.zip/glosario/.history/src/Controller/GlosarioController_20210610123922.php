<?php
// src/Controller/GlosarioController.php
namespace App\Controller;
use App\Entity\Glosario;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController {
    public function portada() {
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        /* Obtenenemos el repositorio de Glosario y buscamos en el usando la id de la palabra */
        $palabras = $entityManager->getRepository(Glosario::class)->findAll();

        /* Pasamos la palabra a una plantilla que se encargue de mostrar sus datos. */
        return $this->render('portada.html.twig', array(
            'palabras' => $palabras,
        ));
    }

    public function definicion($id) {
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        /* Obtenenemos el repositorio de Glosario y buscamos en el usando la id de la palabra */
        $datos = $entityManager->getRepository(Glosario::class)->find($id);

        /* Pasamos la palabra a una plantilla que se encargue de mostrar sus datos. */
        return $this->render('definicion.html.twig', array(
            'datos' => $datos,
        ));
    }

}