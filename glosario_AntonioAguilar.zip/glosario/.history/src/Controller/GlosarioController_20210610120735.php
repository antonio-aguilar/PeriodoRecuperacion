<?php
// src/Controller/GlosarioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada()
    {
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        /* Obtenenemos el repositorio de Apuestas y buscamos en el usando la id de la apuesta */
        $datos = $entityManager->getRepository(Glosario::class)->find($id);
        // Si la apuesta no existe lanzamos una excepción.
        if (!$datos){
            throw $this->createNotFoundException(
                'No existe ninguna apuesta con id '.$id
            );
        }
        /* Pasamos la apuesta a una plantilla que se encargue de mostrar sus datos. */
        return $this->render('portada.html.twig', array(
            'apuesta' => $datos,
        ));
        
        /*$datos = "SELECT * FROM `glosario`";
        return $this->render('portada.html.twig', array(
            'datos' => $datos
        ));*/
        
    }
}