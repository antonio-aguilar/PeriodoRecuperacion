<?php
// src/Controller/GlosarioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada()
    {
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        $datos = $entityManager->getRepository(glosario::class)->findAll();

        return $this->render('portada.html.twig', array(
            'datos' => $datos
        ));
        
    }
}