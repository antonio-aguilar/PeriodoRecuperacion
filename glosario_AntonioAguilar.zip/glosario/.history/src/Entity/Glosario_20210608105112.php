<?php

namespace App\Entity;

use App\Repository\GlosarioRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=GlosarioRepository::class)
 */
class Glosario
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $palabra;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $definicion;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPalabra(): ?string
    {
        return $this->palabra;
    }

    public function setPalabra(string $palabra): self
    {
        $this->palabra = $palabra;

        return $this;
    }

    public function getDefinicion(): ?string
    {
        return $this->definicion;
    }

    public function setDefinicion(string $definicion): self
    {
        $this->definicion = $definicion;

        return $this;
    }
}
