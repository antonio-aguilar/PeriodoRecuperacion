<?php

namespace App\Entity;

use App\Repository\GlosarioRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=GlosarioRepository::class)
 */
class Glosario
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $glosario;

    /**
     * @ORM\Column(type="integer")
     */
    private $ID;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $palabra;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $definicion;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getGlosario(): ?int
    {
        return $this->glosario;
    }

    public function setGlosario(int $glosario): self
    {
        $this->glosario = $glosario;

        return $this;
    }

    public function setID(int $ID): self
    {
        $this->ID = $ID;

        return $this;
    }

    public function getPalabra(): ?string
    {
        return $this->palabra;
    }

    public function setPalabra(string $palabra): self
    {
        $this->palabra = $palabra;

        return $this;
    }

    public function getDefinicion(): ?string
    {
        return $this->definicion;
    }

    public function setDefinicion(string $definicion): self
    {
        $this->definicion = $definicion;

        return $this;
    }
}
