<?php
// src/Controller/GlosarioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada()
    {
        $datos = "SELECT palabra FROM `glosario` WHERE 1";
        return $this->render('portada.html.twig', array(
            'datos' => $datos
        ));
    }
}