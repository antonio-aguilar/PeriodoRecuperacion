<?php
// src/Controller/GlosarioController.php
namespace App\Controller;
use Glosario;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada()
    {
        
        // Obtenemos el gestor de entidades de Doctrine
        $entityManager = $this->getDoctrine()->getManager();
        /* Obtenenemos el repositorio de Apuestas y buscamos en el usando la id de la apuesta */
        $datos = $entityManager->getRepository(Glosario::class)->findAll();

        /* Pasamos la apuesta a una plantilla que se encargue de mostrar sus datos. */
        return $this->render('portada.html.twig', array(
            'datos' => $datos,
        ));
        
        /*$datos = "SELECT * FROM `glosario`";
        return $this->render('portada.html.twig', array(
            'datos' => $datos
        ));*/
        
    }
}