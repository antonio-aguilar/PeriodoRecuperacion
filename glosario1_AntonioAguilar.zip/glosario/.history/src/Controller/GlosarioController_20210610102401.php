<?php
// src/Controller/GlosarioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada($maximo)
    {
        $numero = random_int(0, $maximo);

        return $this->render('sorteo/numero.html.twig', [
            'numero' => $numero,
        ]);
    }
}