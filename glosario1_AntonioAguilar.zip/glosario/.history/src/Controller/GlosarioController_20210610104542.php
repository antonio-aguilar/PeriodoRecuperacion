<?php
// src/Controller/GlosarioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada()
    {
        $datos = $entityManager->getRepository(Glosario::class)->findAll();

        return $this->render('portada.html.twig', array(
            'datos' => $datos,
        ));
        
    }
}