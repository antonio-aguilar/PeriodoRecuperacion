<?php
// src/Controller/GlosarioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GlosarioController extends AbstractController
{
    public function portada()
    {
        $datos = $repository->findAll();
        
    }
}